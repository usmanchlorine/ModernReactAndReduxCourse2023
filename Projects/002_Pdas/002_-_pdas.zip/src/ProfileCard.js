function ProfileCard() {
  return <div>Profile Card!!!</div>;
}

export default ProfileCard;
