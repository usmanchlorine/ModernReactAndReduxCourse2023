function CarList() {
  return <div>CarList</div>;
}

export default CarList;
