function CarForm() {
  return <div>CarForm</div>;
}

export default CarForm;
