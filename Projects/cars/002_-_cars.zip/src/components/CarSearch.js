function CarSearch() {
  return <div>CarSearch</div>;
}

export default CarSearch;
